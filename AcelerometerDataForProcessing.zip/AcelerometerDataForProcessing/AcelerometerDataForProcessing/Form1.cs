﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using System.IO;

namespace AcelerometerDataForProcessing
{
    public partial class Form1 : Form
    {
        String s,com = "";
        string line;
        bool save = false;
        StreamWriter File = new StreamWriter("Data.csv");
        public Form1()
        {
            InitializeComponent();
            string[] ports = SerialPort.GetPortNames();
            foreach (string port in ports)
            {
                comboBox1.Items.Add(port);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem.ToString().Length > 3 && comboBox2.SelectedItem.ToString().Length > 3)
            {
                serialPort1.PortName = comboBox1.SelectedItem.ToString();
                int bauRate = Int32.Parse(comboBox2.SelectedItem.ToString());
                serialPort1.BaudRate = bauRate;
                textBox1.Text = bauRate + "";
                try
                {
                    if (!serialPort1.IsOpen)
                    {
                        serialPort1.Open();
                        comboBox1.Hide();
                        comboBox2.Hide();
                        label1.Hide();
                        label2.Hide();
                        button1.Hide();
                    }
                }
                catch (Exception ex)
                {

                }
            }
        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            try
            {
                line = serialPort1.ReadLine();
                this.BeginInvoke(new LineReceivedEvent(LineReceived), line);
            }
            catch (Exception ex)
            {

            }

        }

        private delegate void LineReceivedEvent(string line);
        private void LineReceived(string line)
        {
            try
            {
                textBox1.Text = line;
                if (save)
                {
               
                    File.Write(line);
                    File.Write("\n");
                    
                }
            }
            catch (Exception ex)
            {

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            serialPort1.Close();
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            save = !save;
            if (save)
            {
                button2.Text = "Pause";
            }
            else
            {
                button2.Text = "Save";
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            serialPort1.DataReceived += serialPort1_DataReceived;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            save = false;
            if (save)
            {
                button2.Text = "Pause";
            }
            else
            {
                button2.Text = "Save";
            }
            File.Close();
        }
    }
}
